package com.management.event.dto;

import lombok.Data;

@Data
public class EventDTO {
	private Long userId;
	private String eventBookingId;
}
